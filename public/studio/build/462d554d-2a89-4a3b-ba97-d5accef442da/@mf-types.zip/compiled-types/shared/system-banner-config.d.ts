export type EnvironmentRequestResponseData = {
    environment: string;
    text: string;
    color?: string;
};
export declare enum ENVIRONMENT {
    DEV = "dev",
    TEST = "test",
    STAGE = "stage",
    PROD = "prod"
}
export declare const environmentAliases: {
    [key: string]: Array<string>;
};
export declare function fetchEnvironment(): Promise<EnvironmentRequestResponseData>;
export declare function getSystemType(environment: string): string;
