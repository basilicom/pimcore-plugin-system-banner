import React from 'react';
export declare const SystemBannerInfo: () => React.JSX.Element;
