import React from 'react';
export declare const SystemBannerLabel: ({ text, color }: {
    text: string;
    color: string;
}) => React.JSX.Element;
