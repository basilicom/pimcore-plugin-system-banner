import { type AbstractModule } from '@pimcore/studio-ui-bundle';
export declare const LoginFormExtension: AbstractModule;
