import React from 'react';
export declare const SystemBannerLogin: () => React.JSX.Element | null;
