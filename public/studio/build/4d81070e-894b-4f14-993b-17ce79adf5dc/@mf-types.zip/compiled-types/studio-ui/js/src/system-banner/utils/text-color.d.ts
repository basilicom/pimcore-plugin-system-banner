export declare const textColorFor: (backgroundColor: string) => string;
