export type LoginBanner = {
    text: string;
    color: string | null;
};
export declare const getLoginBanner: () => LoginBanner | undefined;
